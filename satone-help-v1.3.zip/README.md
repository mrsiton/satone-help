# 聪音代工 · Satone Help 整合包 v1.1

《与你共享：放松时光 / Chill with You : Lo-Fi Story》的聊天模组。

在游戏底部按钮栏「**特别**」和「**转换心情**」之间加一个圆形「聊天」按钮（用的是游戏本体「聊天记录」按钮的同一套图标与故障色特效，图标旋转 90°），
点开是与聪音（Satone）的聊天窗口：接大模型、能读写文件、跑命令、开系统文件选择框，也能在休息时主动给你发消息。

- 不修改任何游戏原始文件，也不碰系统文件；只用 BepInEx 外挂一个插件。
- 模型走你本机的 DSH 客户端网关（或任何 OpenAI 兼容接口）。

---

## 一、安装（3 步）

1. **完全退出游戏**（Steam 里退出，任务管理器里不应有 `Chill With You.exe`）。
2. 把整合包里的这三样**复制到游戏根目录**（覆盖同名文件）：
   - `winhttp.dll`
   - `doorstop_config.ini`
   - `BepInEx\`（整个文件夹）
3. 用 Steam 正常启动游戏。

> 默认游戏目录：`D:\SteamLibrary\steamapps\common\Chill with You Lo-Fi Story`
> 装好后应存在：`<游戏目录>\BepInEx\plugins\SatoneHelp\SatoneHelp.dll`

**验证**：进入房间后几秒，底部按钮栏出现「聊天」圆形按钮（在「特别」右边）；点它能打开聊天窗。
游戏进入沉浸模式（鼠标静止久了会自动隐藏 UI）时按钮会一起隐藏，此时按 **F8** 也能开合聊天窗。

没出现就看两个日志：
- `<游戏目录>\BepInEx\SatoneHelp\satone-help.log`
- `<游戏目录>\BepInEx\LogOutput.log`

---

## 二、首次使用

1. 点「聊天」→ 右上角 **齿轮（设置）**。
2. 默认已填好本机 DSH 客户端的本地网关：
   - 接口地址 `http://127.0.0.1:8326`
   - API Key 自动从 `%USERPROFILE%\.dsh\openai-gateway\api-key` 读取
   - 模型 `deepseek-account/deepseek-flash`
   点 **测试连接**，成功即可。
3. **DSH 会自动启动**（DSH = **DeepSeek Harness** 桌面客户端）：游戏启动约 8 秒后，若本地网关（`127.0.0.1:8326`）不通，模组会把它拉起来。
   查找顺序：`config.json` 的 `dshPath` → **正在运行的 DeepSeek Harness 进程**（读它的真实安装路径，最可靠）→ 常见安装位置
   （`%LOCALAPPDATA%\Programs\DeepSeek Harness\DeepSeek Harness.exe` 等，见 `AGENT-INSTALL.md`）。
   已经在运行时不会重复启动。日志会明确打印解析结果：`dsh exe: <路径>`、`dsh gateway already up` 或 `dsh launched: <路径>`。
   想关掉这个行为：`config.json` 里 `autoStartDsh` 设为 `false`。装在非默认路径时填 `"dshPath": "D:\...\DeepSeek Harness.exe"`。
4. 换模型：点「模型」那一行循环切换 —— 列表来自网关 `/v1/models`，**与 DSH 客户端同步**。
5. 想直连 DeepSeek 官方：接口地址改 `https://api.deepseek.com`，填自己的 API Key，模型 `deepseek-chat`。

---

## 三、能做什么

| 功能 | 说明 |
|---|---|
| 聊天 | 和聪音对话，语气取自游戏本体台词语料（角色卡可改：`BepInEx\SatoneHelp\character\satone_card.txt`） |
| 短句回复 | 她的回复会自动拆成一句一条、逐条冒出来，不会甩一大段 |
| 工具调用 | 会 `list_dir / read_file / write_file / run_cmd`，工作区锁在 `BepInEx\SatoneHelp\workspace\` |
| 传文件 | 输入框左边的 📄 打开**系统文件选择框**，选中的文件会复制进工作区 |
| 记忆 | 每次上线清空对话，但会把上一次的对话提炼成几条"关于你的长期记忆"存进 `memory.md`，下次带上 |
| 生日 | 读取游戏里你填的生日；当天第一次打开会主动说一句祝福（一天一次） |
| 随机消息 | 设置里开「随机消息」并调频率（0.5–30 分钟），她会在你休息时主动发消息，按钮上出现红点 |
| 自动启动 DSH | 游戏起来后自动把 DSH 客户端拉起（网关就绪则跳过），无需先手动开 |
| 沉浸模式 | 按 **F8** 随时开合聊天窗 |
| 窗口操作 | 顶部六点拖动、右下六点缩放、输入框随内容长高（最多三行）、消息区滚轮平滑滚动 |
| 皮肤 | `BepInEx\SatoneHelp\skin\` 放同名 PNG 即可替换（见下） |

---

## 四、改皮肤

`BepInEx\SatoneHelp\skin\` 下这几张（都是**白色 + 透明度**，颜色由代码染）：

| 文件 | 用途 |
|---|---|
| `round.png` | 聊天窗 / 设置窗的大底板（九宫格，圆角由图片决定） |
| `round_small.png` | 标题栏、消息气泡、输入框、按钮 |
| `pill.png` | 开关底、滑条轨道 |
| `circle.png` | 发送键、滑条把手、关闭钮 |
| `bubble_icon.png` | 入口按钮里的图标（找不到才用本体图标） |
| `sent.png` | 发送键图标（可选） |

改完**重启游戏**生效。详细尺寸/色值见 `SKIN-ASSETS.md`。

---

## 五、文件位置

```
<游戏>\BepInEx\plugins\SatoneHelp\SatoneHelp.dll   插件本体
<游戏>\BepInEx\SatoneHelp\
    config.json                 配置（界面上改的就是它；含 autoStartDsh / dshPath）
    history.json                当前会话记录（下线会被提炼进 memory.md 后删除）
    memory.md                   长期记忆（最多 1500 字）
    birthday.txt                当天是否已祝福
    character\satone_card.txt   角色卡
    avatars\                    头像（本体左上角图标裁的）
    skin\                       皮肤 PNG
    workspace\                  她能读写的目录（传进来的文件也在这里）
    satone-help.log             运行日志
```

---

## 六、回滚（三种，任选）

1. **最彻底**：删掉 `<游戏>\BepInEx\`、`winhttp.dll`、`doorstop_config.ini` 三样，游戏即恢复原样（本体文件从未被修改）。
2. **只停用模组**：把 `BepInEx\plugins\SatoneHelp\` 改名或删除，BepInEx 仍在但不再加载插件。
3. **只想清数据**：删 `BepInEx\SatoneHelp\`（配置、记忆、扮演数据全清），插件下次启动会重建默认配置。

---

## 七、常见问题

**启动后没有按钮**
看 `satone-help.log` 是否出现 `chat button parented to LeftIcons` 与 `ui built`。
若日志停在 `AssetLoad`，是游戏自身的双进程启动行为，再启动一次即可。

**点开聊天窗但一直"未连接"**
若日志有 `dsh not found`，说明 DSH 不在默认安装位置：在 `config.json` 填 `dshPath` 指向 `DeepSeek Harness.exe`，或手动启动 DSH。
设置里点「测试连接」。若是 DSH 网关，确认 DSH 客户端在运行；直连官方接口则检查 Key 与接口地址。

**Steam 卡在"正在启动"**
与本模组无关：Steam 偶尔卡在 `CheckShaderDepotManifest`。
解决：完全退出 Steam → 删除 `steamapps\shadercache\3548580` → 重开 Steam → 启动游戏。

**按钮/窗口和截图不一样**
皮肤或分辨率缩放导致。窗口尺寸、字体大小都按本体 1728×1080 的 UI 参考分辨率换算，换分辨率会自动适配。

**会不会改坏游戏/系统**
不会。只新增上面三个文件；不写注册表、不改游戏资源、不碰系统目录（只**读** DSH 的 api-key）。

---

## 八、已知限制

- 只在 **Unity 2022.3.62f2 + Mono** 这一版验证过；游戏换引擎版本需要重新编译插件。
- 长期记忆每个会话只能提炼一次，上限 1500 字；对话原文不保留。
- 工具调用只在她"想用"时触发，不能保证每次都主动读文件。
- 生日祝福当天只发一次（想重测就删 `birthday.txt`）。
