# 安装 Satone Help 模组
# 用法：右键本文件 -> "使用 PowerShell 运行"（游戏必须先完全退出）

$ErrorActionPreference = "Stop"
$src  = Split-Path -Parent $MyInvocation.MyCommand.Path
$game = "D:\SteamLibrary\steamapps\common\Chill with You Lo-Fi Story"

if (-not (Test-Path (Join-Path $game "Chill With You.exe"))) {
    $game = Read-Host "没有找到默认游戏目录，请粘贴游戏根目录路径（包含 Chill With You.exe）"
}
if (-not (Test-Path (Join-Path $game "Chill With You.exe"))) {
    Write-Host "路径里没有 Chill With You.exe，已中止。"
    Read-Host "按回车关闭"; exit 1
}

Write-Host "游戏目录: $game"
Get-Process "Chill With You" -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep -Seconds 2

Copy-Item (Join-Path $src "winhttp.dll")        $game -Force
Copy-Item (Join-Path $src "doorstop_config.ini") $game -Force
Copy-Item (Join-Path $src "BepInEx")            $game -Recurse -Force

$dll = Join-Path $game "BepInEx\plugins\SatoneHelp\SatoneHelp.dll"
if (Test-Path $dll) {
    Write-Host "安装完成：$dll"
    Write-Host "现在可以用 Steam 启动游戏，进房间后底部会出现「聊天」按钮。"
} else {
    Write-Host "安装似乎失败了：找不到 $dll"
}
Read-Host "按回车关闭"
