# 卸载 Satone Help 模组（回滚到原版）
# 用法：右键本文件 -> "使用 PowerShell 运行"
# 说明：本模组不修改任何游戏原始文件，删除下列内容即完全恢复原版。

$ErrorActionPreference = "Stop"
$game = "D:\SteamLibrary\steamapps\common\Chill with You Lo-Fi Story"

if (-not (Test-Path $game)) {
    $game = Read-Host "没有找到默认游戏目录，请粘贴游戏根目录路径"
}

Write-Host "游戏目录: $game"
Get-Process "Chill With You" -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep -Seconds 2

$targets = @(
    (Join-Path $game "BepInEx"),
    (Join-Path $game "winhttp.dll"),
    (Join-Path $game "doorstop_config.ini")
)

foreach ($t in $targets) {
    if (Test-Path $t) {
        Remove-Item $t -Recurse -Force
        Write-Host "已删除 $t"
    } else {
        Write-Host "跳过（不存在）$t"
    }
}

Write-Host ""
Write-Host "完成。游戏已回到原版状态，存档未受影响。"
Read-Host "按回车关闭"
